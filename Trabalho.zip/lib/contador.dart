import 'package:flutter/material.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';

class TelaContador extends StatefulWidget {
  @override
  _TelaContadorState createState() => _TelaContadorState();
}

class _TelaContadorState extends State<TelaContador> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contador de Clicks'),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Contador(tituloContador: 'Contador'),
            ]),
      ),
    );
  }
}

class Contador extends StatefulWidget {
  final String tituloContador;
  const Contador({super.key, required this.tituloContador});

  @override
  State<Contador> createState() => _ContadorState();
}

class _ContadorState extends State<Contador> {
  int nivel = 0;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Palheta.primary,
              borderRadius: BorderRadius.circular(8),
            ),
            height: 280,
          ),
          Positioned.fill(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    height: 150,
                    width: 150,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        nivel.toString(),
                        style: TextStyle(
                          color: Palheta.primary,
                          fontSize: 50,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton(
                        onPressed: () {
                          setState(() {
                            nivel = 0;
                          });
                        },
                        style: OutlinedButton.styleFrom(
                          minimumSize: Size(60, 60),
                          side: BorderSide(color: Colors.white),
                          shape: CircleBorder(),
                        ),
                        child: Icon(Icons.restart_alt,
                            size: 40, color: Colors.white),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      OutlinedButton(
                        onPressed: () {
                          setState(() {
                            nivel++;
                          });
                        },
                        style: OutlinedButton.styleFrom(
                          minimumSize: Size(60.0, 60.0),
                          side: BorderSide(color: Colors.white),
                          shape: CircleBorder(),
                        ),
                        child: Icon(Icons.add, size: 40, color: Colors.white),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

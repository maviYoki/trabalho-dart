import 'package:flutter/material.dart';

class Palheta {
  static const Color primary = Color(0xFFD3AB9E);
  static const Color secondary = Color(0xFFEAC9C1);
  static const Color background = Color(0xFFEBE8D0);
  static const Color surface = Color(0xFFFFFBFF);
  static const Color onPrimary = Color(0xFFFEFEFF);

  static const Color border = Color(0xFFEAC9C1);
  static const Color checkbox = Color(0xFFD3AB9E);
  static const Color radio = Color(0xFFD3AB9E);
  static const Color titleBox = Color(0xFFD3AB9E);
}

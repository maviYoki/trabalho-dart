import 'package:flutter/material.dart';
import 'palheta.dart';

class TextoEstilos {
  static const TextStyle appBarTitulo = TextStyle(
    fontWeight: FontWeight.bold,
    color: Palheta.onPrimary,
    fontSize: 25,
  );

  static const TextStyle tituloCorpo = TextStyle(
    fontWeight: FontWeight.bold,
    color: Colors.white,
    fontSize: 25,
  );

  static const TextStyle textoForm = TextStyle(
    fontSize: 16,
    color: Colors.black87,
  );

  static const TextStyle tituloCampo = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 16,
    color: Palheta.primary,
  );

  static const TextStyle textoButton = TextStyle(
    fontSize: 17,
    color: Colors.white,
  );

  static const TextStyle textoBoxAlert = TextStyle(
    fontSize: 17,
    color: Palheta.primary,
  );
}

import 'package:flutter/material.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';
import 'dart:math';

class TelaPedido extends StatefulWidget {
  @override
  _TelaPedidoState createState() => _TelaPedidoState();
}

class _TelaPedidoState extends State<TelaPedido> {
  final _formKey = GlobalKey<FormState>();

  void fazerPedido() async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(
          color: Palheta.primary,
        ),
      ),
    );
    await Future.delayed(Duration(seconds: 2));

    Navigator.of(context).pop();

    final sucesso = Random().nextBool();

    if (sucesso) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pedido realizado com sucesso')),
      );
    } else {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            title: Text(
              'Erro',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Text('Erro ao realizar o pedido.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  fazerPedido();
                },
                child: Text(
                  'Tentar Novamente',
                  style: TextoEstilos.textoBoxAlert,
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
                child: Text(
                  'Voltar',
                  style: TextoEstilos.textoBoxAlert,
                ),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pedido'),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Center(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Palheta.primary,
                foregroundColor: Palheta.onPrimary,
              ),
              onPressed: () {
                fazerPedido();
              },
              child: Text(
                'Fazer Pedido',
                style: TextoEstilos.textoButton,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'login.dart';
import 'package:helloworld/cadastro.dart';
import 'package:helloworld/contador.dart';
import 'package:helloworld/formulario.dart';
import 'pedido.dart';
import 'dashboard.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';

class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard"),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 200,
              height: 40,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Palheta.primary,
                  foregroundColor: Palheta.onPrimary,
                ),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => TelaContador()));
                },
                child: Text(
                  'Contador',
                  style: TextoEstilos.textoButton,
                ),
              ),
            ),
            SizedBox(height: 16),
            SizedBox(
              width: 200,
              height: 40,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Palheta.primary,
                  foregroundColor: Palheta.onPrimary,
                ),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => TelaFormulario()));
                },
                child: Text(
                  'Formulario',
                  style: TextoEstilos.textoButton,
                ),
              ),
            ),
            SizedBox(height: 16),
            SizedBox(
              width: 200,
              height: 40,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Palheta.primary,
                  foregroundColor: Palheta.onPrimary,
                ),
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => TelaPedido()));
                },
                child: Text(
                  'Pedido',
                  style: TextoEstilos.textoButton,
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: TextButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: Palheta.primary,
            foregroundColor: Palheta.onPrimary,
          ),
          onPressed: () {
            Navigator.pushReplacementNamed(context, '/login');
          },
          icon: Icon(Icons.logout),
          label: Text('Logout'),
        ),
      ),
    );
  }
}

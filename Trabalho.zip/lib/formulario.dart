import 'package:flutter/material.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';

class TelaFormulario extends StatefulWidget {
  @override
  _TelaFormularioState createState() => _TelaFormularioState();
}

class _TelaFormularioState extends State<TelaFormulario> {
  final _formKey = GlobalKey<FormState>();

  List<bool> hobbiesAtivo = [false, false, false, false];
  List<String> hobbiesNomes = ['Nadar', 'Pintar', 'Cantar', 'Dançar'];

  List<int> idades = List.generate(100, (i) => i + 15);

  String? idadeSelecionada;
  String? frequenciaSelecionada;

  void guardarDados() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      List<String> hobbieSelecionado = [];
      for (int i = 0; i < hobbiesAtivo.length; i++) {
        if (hobbiesAtivo[i]) {
          hobbieSelecionado.add(hobbiesNomes[i]);
        }
      }
      print("Faixa Etaria: $idadeSelecionada");
      print("Hobbies: ${hobbieSelecionado.join(', ')}");
      print("Frequencia: $frequenciaSelecionada");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Dados salvos com sucesso!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formulário de Pesquisa'),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _FaixaEtariaDropMenu(),
                SizedBox(height: 20),
                Column(children: _HobbiesCheckBox()),
                SizedBox(height: 20),
                _RadioFrequenciaExerc(),
                SizedBox(height: 30),
                _BotaoSalvarValidar(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _FaixaEtariaDropMenu() {
    return DropdownButtonFormField<String>(
      validator: (value) => value == null ? 'Selecione uma idade' : null,
      decoration: InputDecoration(
        labelText: 'Faixa Étaria',
        filled: true,
        fillColor: Palheta.surface,
        labelStyle: TextoEstilos.textoForm,
        border: OutlineInputBorder(),
      ),
      value: idadeSelecionada,
      items: idades
          .map((i) => DropdownMenuItem(
                value: i.toString(),
                child: Text(i.toString()),
              ))
          .toList(),
      onChanged: (value) {
        setState(() {
          idadeSelecionada = value;
        });
      },
    );
  }

  List<Widget> _HobbiesCheckBox() {
    List<Widget> checkboxes = [];
    for (int i = 0; hobbiesNomes.length > i; i++) {
      checkboxes.add(CheckboxListTile(
        title: Text(hobbiesNomes[i]),
        value: hobbiesAtivo[i],
        onChanged: (value) {
          setState(() {
            hobbiesAtivo[i] = value!;
          });
        },
        activeColor: Palheta.checkbox,
      ));
    }
    return checkboxes;
  }

  Widget _RadioFrequenciaExerc() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Frequência na prática de atividade físicas',
          style: TextoEstilos.tituloCampo,
        ),
        SizedBox(height: 15),
        Column(
          children: [
            RadioListTile<String>(
              title: Text('Nunca'),
              value: 'Nunca',
              groupValue: frequenciaSelecionada,
              onChanged: (value) {
                setState(() {
                  frequenciaSelecionada = value;
                });
              },
              activeColor: Palheta.radio,
            ),
            RadioListTile<String>(
              title: Text('1-2 vezes por semana'),
              value: '1-2 vezes por semana',
              groupValue: frequenciaSelecionada,
              onChanged: (value) {
                setState(() {
                  frequenciaSelecionada = value;
                });
              },
              activeColor: Palheta.radio,
            ),
            RadioListTile<String>(
              title: Text('Mais de 3 vezes'),
              value: 'Mais de 3 vezes',
              groupValue: frequenciaSelecionada,
              onChanged: (value) {
                setState(() {
                  frequenciaSelecionada = value;
                });
              },
              activeColor: Palheta.radio,
            ),
          ],
        ),
      ],
    );
  }

  Widget _BotaoSalvarValidar() {
    return Center(
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Palheta.primary,
            foregroundColor: Palheta.onPrimary,
          ),
          onPressed: guardarDados,
          child: Text('Salvar', style: TextoEstilos.textoButton)),
    );
  }
}

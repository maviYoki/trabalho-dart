import 'package:flutter/material.dart';
import 'login.dart';
import 'package:helloworld/cadastro.dart';
import 'package:helloworld/contador.dart';
import 'package:helloworld/formulario.dart';
import 'pedido.dart';
import 'dashboard.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meu App',
      initialRoute: '/login',
      routes: {
        '/login': (context) => TelaLogin(),
        '/dashboard': (context) => Dashboard(),
        '/cadastro': (context) => TelaCadastro(),
      },
    );
  }
}

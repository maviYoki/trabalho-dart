import 'package:flutter/material.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';
import 'dashboard.dart';

class TelaCadastro extends StatefulWidget {
  @override
  _TelaCadastroState createState() => _TelaCadastroState();
}

bool validarEmail(String email) {
  if (email.isEmpty) return false;

  List<String> partesEntrada = email.split('@');
  if (partesEntrada.length != 2) return false;

  String nomeUsuario = partesEntrada[0];
  String dominio = partesEntrada[1];

  if (nomeUsuario.isEmpty ||
      nomeUsuario.contains(' ') ||
      nomeUsuario.contains('..') ||
      !RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(nomeUsuario)) {
    return false;
  }

  if (!dominio.contains('.')) return false;

  List<String> partesDominio = dominio.split('.');
  if (partesDominio.length < 2) return false;

  String nomeDominio = partesDominio[0];
  String aposDominio = partesDominio.last;

  if (nomeDominio.isEmpty ||
      nomeDominio.contains(' ') ||
      aposDominio.isEmpty ||
      aposDominio.contains(' ') ||
      aposDominio.length < 2 ||
      !RegExp(r'^[a-zA-Z]+$').hasMatch(aposDominio)) {
    return false;
  }

  return true;
}

bool validarCPF(String cpf) {
  cpf = cpf.replaceAll(RegExp(r'[^0-9]'), '');
  if (cpf.length != 11 || RegExp(r'^(\d)\1{10}$').hasMatch(cpf)) {
    return false;
  }
  int soma = 0;
  for (int i = 0; i < 9; i++) {
    soma += int.parse(cpf[i]) * (10 - i);
  }
  int digito1 = (soma * 10) % 11;
  if (digito1 == 10) digito1 = 0;
  soma = 0;
  for (int i = 0; i < 10; i++) {
    soma += int.parse(cpf[i]) * (11 - i);
  }
  int digito2 = (soma * 10) % 11;
  if (digito2 == 10) digito2 = 0;
  return cpf[9] == digito1.toString() && cpf[10] == digito2.toString();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController campoNome = TextEditingController();
  final TextEditingController campoEmail = TextEditingController();
  final TextEditingController campoCpf = TextEditingController();
  final TextEditingController campoSenha = TextEditingController();
  bool aceitouTermos = false;

  void guardarDados() {
    String nome = campoNome.text;
    String email = campoEmail.text;
    String cpf = campoCpf.text;
    String senha = campoSenha.text;

    print("Nome: $nome");
    print("E-mail: $email");
    print("CPF: $cpf");
    print("Descrição: $senha");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cadastro"),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _NomeTextField(),
                SizedBox(height: 16),
                _EmailTextField(),
                SizedBox(height: 16),
                _CpfTextField(),
                SizedBox(height: 16),
                _SenhaTextField(),
                SizedBox(
                  height: 16,
                ),
                _TermosCheckboxTitle(),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Palheta.primary,
                      foregroundColor: Palheta.onPrimary,
                    ),
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        if (!aceitouTermos) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content:
                                  Text('Aceite os termos para continuar')));
                        } else
                          guardarDados();
                        Navigator.pushReplacementNamed(context, '/dashboard');
                      }
                    },
                    child: Text(
                      'Cadastrar',
                      style: TextoEstilos.textoButton,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _NomeTextField() {
    return TextFormField(
      controller: campoNome,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        filled: true,
        fillColor: Palheta.surface,
        labelText: 'Nome',
        labelStyle: TextoEstilos.textoForm,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Campo obrigatório';
        }
        if (value.length < 3) {
          return 'Seu nome tem que ter pelo menos 3 letras';
        }
        return null;
      },
    );
  }

  Widget _EmailTextField() {
    return TextFormField(
      controller: campoEmail,
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
        labelText: 'E-mail',
        labelStyle: TextoEstilos.textoForm,
        filled: true,
        fillColor: Palheta.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Campo de e-mail obrigatório';
        }
        if (!validarEmail(value)) {
          return 'E-mail inválido';
        }
        return null;
      },
    );
  }

  Widget _CpfTextField() {
    return TextFormField(
      controller: campoCpf,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: 'CPF',
        labelStyle: TextoEstilos.textoForm,
        filled: true,
        fillColor: Palheta.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      onChanged: (value) {
        String apenasNumeros = value.replaceAll(RegExp(r'\D'), '');
        String novoTexto = '';
        for (int i = 0; i < apenasNumeros.length && i < 11; i++) {
          if (i == 3 || i == 6) novoTexto += '.';
          if (i == 9) novoTexto += '-';
          novoTexto += apenasNumeros[i];
        }
        campoCpf.value = TextEditingValue(
          text: novoTexto,
          selection: TextSelection.collapsed(offset: novoTexto.length),
        );
      },
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Campo obrigatório';
        }
        if (!validarCPF(value)) {
          return 'CPF inválido';
        }
        return null;
      },
    );
  }

  Widget _SenhaTextField() {
    return TextFormField(
      controller: campoSenha,
      obscureText: true,
      decoration: InputDecoration(
        labelText: 'Senha',
        labelStyle: TextoEstilos.textoForm,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Senha inválido';
        }
        if (value.length < 7) return "A senha precisa ter pelo menos 6 digitos";
        return null;
      },
    );
  }

  Widget _TermosCheckboxTitle() {
    return CheckboxListTile(
      title: Text('Aceito os termos'),
      value: aceitouTermos,
      onChanged: (value) {
        setState(() => aceitouTermos = value!);
      },
      activeColor: Palheta.checkbox,
    );
  }
}

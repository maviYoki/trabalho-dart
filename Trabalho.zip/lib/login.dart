import 'package:flutter/material.dart';
import 'Estilos/palheta.dart';
import 'Estilos/texto.dart';
import 'cadastro.dart';

class TelaLogin extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<TelaLogin> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController campoEmail = TextEditingController();
  final TextEditingController campoSenha = TextEditingController();

  void guardarDados() {
    String email = campoEmail.text;
    String senha = campoSenha.text;

    print("Nome: $email");
    print("Descrição: $senha");
  }

  bool validarEmail(String email) {
    if (email.isEmpty) return false;

    List<String> partesEntrada = email.split('@');
    if (partesEntrada.length != 2) return false;

    String nomeUsuario = partesEntrada[0];
    String dominio = partesEntrada[1];

    if (nomeUsuario.isEmpty ||
        nomeUsuario.contains(' ') ||
        nomeUsuario.contains('..') ||
        !RegExp(r'^[a-zA-Z0-9_-]+$').hasMatch(nomeUsuario)) {
      return false;
    }

    if (!dominio.contains('.')) return false;

    List<String> partesDominio = dominio.split('.');
    if (partesDominio.length < 2) return false;

    String nomeDominio = partesDominio[0];
    String aposDominio = partesDominio.last;

    if (nomeDominio.isEmpty ||
        nomeDominio.contains(' ') ||
        aposDominio.isEmpty ||
        aposDominio.contains(' ') ||
        aposDominio.length < 2 ||
        !RegExp(r'^[a-zA-Z]+$').hasMatch(aposDominio)) {
      return false;
    }

    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Palheta.primary,
        titleTextStyle: TextoEstilos.appBarTitulo,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _EmailTextField(),
                SizedBox(height: 16),
                _SenhaTextField(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () {
                            Navigator.pushNamed(context, '/cadastro');
                          },
                          child: Text(
                            "Cadastrar-se",
                            style: TextStyle(
                              color: Palheta.primary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Palheta.primary,
                        foregroundColor: Palheta.onPrimary,
                      ),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          guardarDados();
                          Navigator.pushReplacementNamed(context, '/dashboard');
                        }
                      },
                      child: Text(
                        'Logar',
                        style: TextoEstilos.textoButton,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _EmailTextField() {
    return TextFormField(
      controller: campoEmail,
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
        labelText: 'E-mail',
        labelStyle: TextoEstilos.textoForm,
        filled: true,
        fillColor: Palheta.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Campo de e-mail obrigatório';
        }
        if (!validarEmail(value)) {
          return 'E-mail inválido';
        }
        return null;
      },
    );
  }

  Widget _SenhaTextField() {
    return TextFormField(
      controller: campoSenha,
      obscureText: true,
      decoration: InputDecoration(
        labelText: 'Senha',
        labelStyle: TextoEstilos.textoForm,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Senha inválido';
        }
        if (value.length < 7) return "A senha precisa ter pelo menos 6 digitos";
        return null;
      },
    );
  }
}
